This zip files contains 2 files
The tutorial data used in our user study and the task target list (all in the pdf files).